%% SOLUCIÓN APROBADA: KP = 310; KI = 1900; KD = 2,5
clear all;close all;clc
s=tf('s');

Ts = 20e-3;

% Definicion de la Planta 
k_planta = -0.099863;
p_planta = 10.14;
P = k_planta * s/( (s+p_planta) * (s-p_planta) )

p1_cuad = 10.14^2;
A = [0, 1 ; 
     p1_cuad, 0];
B = [-0.099863; 0];
C = [1, 0];
D = 0;

sys_fisc = ss(A, B, C, D);

% x0 = [pos_inicial; velocidad_incial]
x1_0 = 5 * pi / (180);
x2_0 = 0;
x0 = [x1_0; x2_0];

% ----- CONTROLADOR DISEÑO POR LOOP SHAPING----- %
kc = -1 * db2mag(56.5);
C = zpk([-11, -12],[0, -80], kc)
pid(C)

L = minreal(C*P);

% ----- GRAFICOS ----- %
optionss=bodeoptions;
optionss.MagVisible='on';
optionss.PhaseMatching='on';
optionss.PhaseMatchingValue=-180;
optionss.PhaseMatchingFreq=1;
optionss.Grid='on';

%figure();
%bode(L,optionss);title("L")

% ---------- AJUSTE MANUAL DE GANANANCIAS DEL PId = Kp + Ki * 1/s + Kd * s;
k_s = pid(C)
C_pid = (k_s.Kp - 130) + (k_s.Ki - 800) /s + (k_s.Kd+5i)*s/(k_s.Tf * s+1 )

% ----- CONTROL DIGITAL (para simulink)----- %
c_dig = c2d(C_pid, Ts, 'tustin')
simu = pid(C_pid)




%% POSIBLES RESPUESTAS 
% 
% Caso 1) Luego de un rato acelera y cae 
% 	Diagnostico: se acumulo error y el Ki elevado hizo que el error sea mayor
% 	Respuesta: Bajar el Ki
% 
% Caso 2) Si la estabilización es muy variable
% 	Diagnostico: Kd es muy grande y no se asjuta de forma estable
% 	Respuesta: Bajar el Kd


% últ probado en clase 28/04/26: %C_pid = (-316) + (-2100) /s + (0)*s/(k_s.Tf * s+1 ) 